# Campus Residence Analytics — Streamlit

**Transforming student feedback into better housing decisions.**

A single Python (Streamlit) app with two sides:
- **Students** see only the survey (housing evaluation + VIP interest).
- **Administrators** (password) see only the analytics dashboard.

SQLite by default for zero-setup development; PostgreSQL-ready for production.
Every number on the dashboard is computed live from real submissions — no mock data.

---

## Quick start

```bash
pip install -r requirements.txt
python -m app.seed            # import the sample housing roster (reference data)
streamlit run app/main.py     # opens http://localhost:8501
```

Or just: `./run.sh`

- **Admin password:** `iiui-admin` (change via the `ADMIN_PASSWORD` environment variable).
- Switch to PostgreSQL by setting `DATABASE_URL`, e.g.
  `export DATABASE_URL=postgresql://user:pass@host:5432/campus`

---

## How it works

1. **Role gate** — a student starts the survey; an admin signs in to the dashboard. Neither can see the other's screens.
2. **Student information** — full name, student ID, university email, academic level, room, block. All mandatory.
3. **Resident verification** — student ID + email + room are checked against the imported roster. Verified → full housing evaluation. Not found → VIP interest form only.
4. **Survey** — twelve areas rated 1–5 (Very Poor → Excellent). A rating of **1 or 2 makes a comment mandatory**. Plus Main Complaint, Suggested Improvement, Best Thing.
5. **One response per student** — enforced by a unique constraint on (student ID, email, room).
6. **VIP section** — interest, reason, expected features, fee acceptance (15,000–20,000 PKR), barriers, and contact details for interested students.

---

## Dashboard

- **Priority Action Center** — auto-highlights the most problematic block, lowest-rated service, most common complaint, and blocks needing immediate attention.
- **KPI cards** — responses, participation, satisfaction, residents, VIP demand, best/worst block, top complaint, most appreciated service.
- **Housing Health Score (0–100)** per block with Green / Yellow / Red bands.
- **Service performance** — top and lowest performing services.
- **Academic analytics** — counts, percentages, satisfaction by level.
- **Comment insights** — complaints, suggestions, problems, appreciated services.
- **Block drilldown** — pick a block for service ratings, positive/negative comments, suggestions, and common issues.
- **VIP insights** — interest, price acceptance, top features, reasons, barriers.
- **Filters** — block, academic level, satisfaction, VIP interest.
- **Export** — CSV, Excel, and a PDF executive summary.

---

## Importing your real roster

Replace `app/residents.csv` (columns: `student_id,name,email,room,block,academic_level`)
and re-run `python -m app.seed`, or upload a CSV from the admin sign-in screen.

---

## Project layout

```
app/
  main.py        role gate, admin auth, roster import, routing
  survey.py      student survey flow (session-state, validation)
  dashboard.py   admin analytics (Plotly charts, filters, exports)
  analytics.py   pure functions: health score, priority center, comments…
  db.py          SQLAlchemy models + DB setup
  theme.py       CSS + card/alert/bar helpers
  seed.py        roster import
  residents.csv  sample roster
requirements.txt
run.sh
```

## Notes
- Comment analysis is a transparent keyword + rating method (no external NLP). Extend the lexicon in `analytics.py` as real vocabulary appears.
- For institutional sign-in, replace the password gate in `main.py` with your SSO.
