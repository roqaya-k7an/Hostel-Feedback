#!/usr/bin/env bash
# One-command start: install deps, import roster, launch.
pip install -r requirements.txt
python -m app.seed
streamlit run app/main.py
