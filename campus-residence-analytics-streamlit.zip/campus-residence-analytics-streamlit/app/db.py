"""Database layer. SQLite by default (zero setup), PostgreSQL-ready via DATABASE_URL."""
import os
import datetime as dt
from sqlalchemy import (create_engine, Column, Integer, String, Boolean,
                        DateTime, JSON, UniqueConstraint)
from sqlalchemy.orm import sessionmaker, declarative_base

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///campus.db")
_connect = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=_connect, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

# ---- domain vocabulary ----
CATEGORIES = [
    ("clean", "Cleanliness"), ("room", "Room Conditions"),
    ("maint", "Building Maintenance"), ("wifi", "Internet Quality"),
    ("food", "Food Services"), ("sec", "Security Services"),
    ("med", "Medical Center"), ("gym", "Gym Facilities"),
    ("admin_staff", "Administration Staff"), ("wardens", "Wardens"),
    ("regs", "Housing Regulations"), ("overall", "Overall Housing Experience"),
]
CAT_KEYS = [k for k, _ in CATEGORIES]
CAT_LABEL = dict(CATEGORIES)
# eight service areas that feed the Housing Health Score
HEALTH_KEYS = ["clean", "maint", "wifi", "sec", "food", "med", "gym", "admin_staff"]
ACADEMIC_LEVELS = ["Bachelor's", "Master's", "PhD"]
BLOCKS = list("ABCDEFG")
RATING_LABELS = {1: "Very Poor", 2: "Poor", 3: "Average", 4: "Good", 5: "Excellent"}


class Resident(Base):
    __tablename__ = "residents"
    id = Column(Integer, primary_key=True)
    student_id = Column(String, index=True, nullable=False)
    name = Column(String, nullable=False)
    email = Column(String, index=True, nullable=False)
    room = Column(String, nullable=False)
    block = Column(String, nullable=False)
    academic_level = Column(String, nullable=False)
    __table_args__ = (UniqueConstraint("student_id", "email", "room", name="uq_resident"),)


class Submission(Base):
    __tablename__ = "submissions"
    id = Column(Integer, primary_key=True)
    created_at = Column(DateTime, default=dt.datetime.utcnow)
    name = Column(String, nullable=False)
    student_id = Column(String, index=True, nullable=False)
    email = Column(String, index=True, nullable=False)
    academic_level = Column(String, nullable=False)
    room = Column(String, nullable=False)
    block = Column(String, index=True)
    is_resident = Column(Boolean, default=False)

    ratings = Column(JSON, default=dict)
    comments = Column(JSON, default=dict)
    main_complaint = Column(String)
    suggested_improvement = Column(String)
    best_thing = Column(String)

    vip_interested = Column(Boolean, default=False)
    vip_reason = Column(String)
    vip_features = Column(JSON, default=list)
    vip_extra_services = Column(String)
    vip_price_ok = Column(String)        # Yes / Maybe / No
    vip_barrier = Column(JSON, default=list)
    vip_suggestions = Column(String)
    lead_phone = Column(String)

    __table_args__ = (UniqueConstraint("student_id", "email", "room", name="uq_submission_once"),)


def init_db():
    Base.metadata.create_all(bind=engine)
