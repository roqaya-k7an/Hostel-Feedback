"""Framework-free analytics. Operate on a pandas DataFrame of submissions so
they are easy to test and to filter inside Streamlit. Nothing here is mocked."""
from collections import Counter
import pandas as pd
from .db import (SessionLocal, Submission, Resident, CAT_KEYS, CAT_LABEL,
                 HEALTH_KEYS, ACADEMIC_LEVELS, BLOCKS)

# ---------- comment theme lexicon (transparent, extendable) ----------
THEMES = {
    "Wi-Fi / internet": ["wifi", "wi-fi", "internet", "network", "signal", "connection"],
    "Cleaning / hygiene": ["clean", "dirty", "dust", "hygiene", "washroom", "bathroom", "trash"],
    "Food quality": ["food", "meal", "menu", "mess", "canteen", "taste", "stale"],
    "Water / plumbing": ["water", "hot water", "leak", "tap", "geyser", "drain"],
    "Maintenance delays": ["maintenance", "repair", "broken", "fix", "fan", "light", "ac", "electric"],
    "Security / safety": ["security", "safe", "unsafe", "guard", "lock", "theft"],
    "Noise / quiet": ["noise", "noisy", "loud", "quiet", "disturb", "sleep"],
    "Study space": ["study", "library", "desk"],
    "Staff behaviour": ["staff", "warden", "rude", "behav", "attitude", "management"],
    "Gym": ["gym", "equipment", "treadmill", "weights"],
    "Medical": ["medical", "doctor", "nurse", "clinic", "medicine"],
}
SUGGEST_CUES = ["should", "please", "add", "more", "need", "suggest", "could", "provide", "wish"]


def load_dataframe():
    """Read all submissions into a flat DataFrame with rating_<cat> columns."""
    db = SessionLocal()
    subs = db.query(Submission).all()
    rows = []
    for s in subs:
        r = {
            "id": s.id, "created_at": s.created_at, "name": s.name,
            "student_id": s.student_id, "email": s.email,
            "academic_level": s.academic_level, "room": s.room, "block": s.block,
            "is_resident": s.is_resident,
            "main_complaint": s.main_complaint or "", "suggested_improvement": s.suggested_improvement or "",
            "best_thing": s.best_thing or "",
            "vip_interested": s.vip_interested, "vip_reason": s.vip_reason,
            "vip_features": s.vip_features or [], "vip_price_ok": s.vip_price_ok,
            "vip_barrier": s.vip_barrier or [], "lead_phone": s.lead_phone,
            "_ratings": s.ratings or {}, "_comments": s.comments or {},
        }
        for k in CAT_KEYS:
            r[f"rating_{k}"] = (s.ratings or {}).get(k)
        rows.append(r)
    roster = db.query(Resident).count()
    db.close()
    df = pd.DataFrame(rows)
    return df, roster


def health_score(avg_rating):
    """Map a 1-5 average to a 0-100 score."""
    if avg_rating is None or pd.isna(avg_rating):
        return None
    return round((avg_rating - 1) / 4 * 100)


def health_band(score):
    if score is None:
        return ("No data", "#9aa7b8")
    if score >= 75:
        return ("Excellent", "#15735A")
    if score >= 50:
        return ("Needs attention", "#C8862B")
    return ("Critical", "#B5462F")


def _residents(df):
    return df[df["is_resident"] == True] if len(df) else df  # noqa: E712


def overview(df, roster):
    res = _residents(df)
    total = len(df)
    sat = res["rating_overall"].dropna().mean() if len(res) else 0
    part = round(len(res) / roster * 100, 1) if roster else 0.0
    vip = int(df["vip_interested"].sum()) if len(df) else 0
    return {
        "total_responses": total,
        "total_residents": len(res),
        "participation_rate": part,
        "overall_satisfaction": round(float(sat), 2) if sat else 0.0,
        "vip_demand": vip,
        "roster": roster,
    }


def service_scores(df):
    res = _residents(df)
    out = []
    for k in HEALTH_KEYS + ["room", "wardens", "regs"]:
        col = f"rating_{k}"
        if col in res:
            vals = res[col].dropna()
            if len(vals):
                avg = float(vals.mean())
                out.append({"key": k, "label": CAT_LABEL[k], "avg": round(avg, 2),
                            "pct": round((avg - 1) / 4 * 100, 1)})
    out.sort(key=lambda x: x["avg"], reverse=True)
    return out


def block_table(df):
    res = _residents(df)
    rows = []
    for b in BLOCKS:
        m = res[res["block"] == b]
        if not len(m):
            rows.append({"block": b, "residents": 0, "satisfaction": 0.0,
                         "health": None, "complaints": 0, "suggestions": 0})
            continue
        health_avg = m[[f"rating_{k}" for k in HEALTH_KEYS]].stack().mean()
        comp = sum(1 for c in m["main_complaint"] if c.strip())
        sug = sum(1 for c in m["suggested_improvement"] if c.strip())
        rows.append({
            "block": b, "residents": len(m),
            "satisfaction": round(float(m["rating_overall"].dropna().mean() or 0), 2),
            "health": health_score(health_avg),
            "complaints": comp, "suggestions": sug,
        })
    return rows


def block_service_scores(df, block):
    m = _residents(df)
    m = m[m["block"] == block]
    out = {}
    for k in CAT_KEYS:
        vals = m[f"rating_{k}"].dropna()
        out[CAT_LABEL[k]] = round(float(vals.mean()), 2) if len(vals) else 0.0
    return out


def _themes(text):
    t = " " + str(text).lower() + " "
    return [name for name, kws in THEMES.items() if any(k in t for k in kws)]


def comment_insights(df):
    complaints, suggestions, problems, appreciated = Counter(), Counter(), Counter(), Counter()
    res = _residents(df)
    for _, s in res.iterrows():
        ratings = s["_ratings"]
        comments = s["_comments"]
        for k in CAT_KEYS:
            txt = (comments.get(k) or "").strip()
            score = ratings.get(k)
            if not txt:
                continue
            if score in (1, 2):
                problems[CAT_LABEL[k]] += 1
                for th in _themes(txt):
                    complaints[th] += 1
            if score in (4, 5):
                appreciated[CAT_LABEL[k]] += 1
        if s["main_complaint"].strip():
            for th in (_themes(s["main_complaint"]) or ["General"]):
                complaints[th] += 1
        if s["suggested_improvement"].strip():
            for th in (_themes(s["suggested_improvement"]) or ["General suggestion"]):
                suggestions[th] += 1
    top = lambda c, n=6: [{"label": k, "count": v} for k, v in c.most_common(n)]
    return {"complaints": top(complaints), "suggestions": top(suggestions),
            "problems": top(problems), "appreciated": top(appreciated)}


def block_comments(df, block):
    m = _residents(df)
    m = m[m["block"] == block]
    pos, neg, sug = [], [], []
    for _, s in m.iterrows():
        for k in CAT_KEYS:
            txt = (s["_comments"].get(k) or "").strip()
            if not txt:
                continue
            entry = {"area": CAT_LABEL[k], "text": txt, "rating": s["_ratings"].get(k)}
            if s["_ratings"].get(k) in (1, 2):
                neg.append(entry)
            elif s["_ratings"].get(k) in (4, 5):
                pos.append(entry)
        if s["suggested_improvement"].strip():
            sug.append({"area": "Suggestion", "text": s["suggested_improvement"], "rating": None})
    return {"positive": pos, "negative": neg, "suggestions": sug}


def academic_breakdown(df):
    total = len(df) or 1
    out = []
    for lvl in ACADEMIC_LEVELS:
        m = df[df["academic_level"] == lvl]
        sat = _residents(m)["rating_overall"].dropna().mean() if len(m) else 0
        out.append({"level": lvl, "count": len(m), "percent": round(len(m) / total * 100, 1),
                    "satisfaction": round(float(sat), 2) if sat else 0.0})
    return out


def vip_analytics(df):
    total = len(df) or 1
    interested = df[df["vip_interested"] == True]  # noqa: E712
    yes = int((df["vip_price_ok"] == "Yes").sum())
    maybe = int((df["vip_price_ok"] == "Maybe").sum())
    no = int((df["vip_price_ok"] == "No").sum())
    reasons = Counter(r for r in interested["vip_reason"] if r)
    feats = Counter(f for lst in interested["vip_features"] for f in (lst or []))
    barriers = Counter(b for lst in df[df["vip_interested"] == False]["vip_barrier"]  # noqa: E712
                       for b in (lst or []))
    return {
        "interested": len(interested),
        "price_accept_rate": round(yes / total * 100, 1),
        "price_yes": yes, "price_maybe": maybe, "price_no": no,
        "reasons": [{"label": k, "count": v} for k, v in reasons.most_common()],
        "features": [{"label": k, "count": v} for k, v in feats.most_common(8)],
        "barriers": [{"label": k, "count": v} for k, v in barriers.most_common()],
    }


def priority_center(df):
    blocks = [b for b in block_table(df) if b["residents"] > 0 and b["health"] is not None]
    services = service_scores(df)
    insights = comment_insights(df)
    worst_block = min(blocks, key=lambda b: b["health"], default=None)
    worst_service = services[-1] if services else None
    top_complaint = insights["complaints"][0] if insights["complaints"] else None
    attention = [b for b in blocks if b["health"] is not None and b["health"] < 50]
    return {
        "worst_block": worst_block,
        "worst_service": worst_service,
        "top_complaint": top_complaint,
        "critical_blocks": attention,
    }
