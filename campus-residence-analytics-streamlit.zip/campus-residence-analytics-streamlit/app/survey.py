"""Student-facing survey. Multi-step flow via st.session_state. Students never
see analytics. Verification, duplicate-prevention and the smart comment rule are
all enforced before anything is written to the database."""
import streamlit as st
from sqlalchemy.exc import IntegrityError
from .db import (SessionLocal, Resident, Submission, CATEGORIES, CAT_KEYS,
                 ACADEMIC_LEVELS, BLOCKS, RATING_LABELS)

VIP_FEATURES = ["Private room", "Private bathroom", "Air conditioning", "Fast internet",
                "Daily cleaning", "Kitchen access", "Study area", "Premium furniture"]
VIP_REASONS = ["Privacy", "Comfort", "Better Facilities", "Better Environment", "Other"]
VIP_BARRIERS = ["Price", "Location", "Satisfied with current housing", "Not interested", "Other"]


def _ss(key, default):
    if key not in st.session_state:
        st.session_state[key] = default


def reset():
    for k in list(st.session_state.keys()):
        if k.startswith("sv_"):
            del st.session_state[k]


def run_survey():
    _ss("sv_step", "info")
    _ss("sv_info", {})
    _ss("sv_is_resident", False)
    _ss("sv_ratings", {})
    _ss("sv_comments", {})
    step = st.session_state["sv_step"]

    if step == "info":
        _step_info()
    elif step == "verify":
        _step_verify()
    elif step == "survey":
        _step_survey()
    elif step == "vip":
        _step_vip()
    elif step == "done":
        _step_done()


# ---------------- steps ----------------
def _step_info():
    st.subheader("Student information")
    st.caption("All fields are required before you can begin a housing evaluation.")
    info = st.session_state["sv_info"]
    c1, c2 = st.columns(2)
    name = c1.text_input("Full name *", info.get("name", ""))
    sid = c2.text_input("Student ID *", info.get("student_id", ""))
    c3, c4 = st.columns(2)
    email = c3.text_input("University email *", info.get("email", ""))
    room = c4.text_input("Room number *", info.get("room", ""))
    c5, c6 = st.columns(2)
    level = c5.selectbox("Academic level *", [""] + ACADEMIC_LEVELS,
                         index=([""] + ACADEMIC_LEVELS).index(info.get("academic_level", "")) if info.get("academic_level") else 0)
    block = c6.selectbox("Housing block *", [""] + BLOCKS,
                         index=([""] + BLOCKS).index(info.get("block", "")) if info.get("block") else 0)

    valid = all([name.strip(), sid.strip(), email.strip(), room.strip(), level, block])
    if st.button("Continue →", type="primary", disabled=not valid):
        st.session_state["sv_info"] = {"name": name.strip(), "student_id": sid.strip(),
            "email": email.strip(), "room": room.strip(), "academic_level": level, "block": block}
        st.session_state["sv_step"] = "verify"
        st.rerun()
    if not valid:
        st.caption("⚠️ Please complete every field to continue.")


def _step_verify():
    info = st.session_state["sv_info"]
    st.subheader("Confirm your residence")
    st.caption("We check your details against the official housing roster.")
    st.markdown(f"**{info['name']}** · {info['student_id']}  \n{info['email']} · Room {info['room']} · Block {info['block']}")

    db = SessionLocal()
    res = db.query(Resident).filter_by(student_id=info["student_id"], email=info["email"], room=info["room"]).first()
    db.close()
    st.session_state["sv_is_resident"] = bool(res)

    if res:
        st.success("✓ Verified resident. The full housing evaluation is unlocked.")
    else:
        st.warning("ⓘ Not found in the housing roster. You can still register VIP housing interest.")

    c1, c2 = st.columns([1, 1])
    if c1.button("← Back"):
        st.session_state["sv_step"] = "info"; st.rerun()
    if c2.button(("Begin evaluation →" if res else "Continue to VIP →"), type="primary"):
        st.session_state["sv_step"] = "survey" if res else "vip"; st.rerun()


def _step_survey():
    st.subheader("Housing evaluation")
    st.caption("Rate each area from 1 (Very Poor) to 5 (Excellent). A rating of 1 or 2 requires a short comment.")
    ratings = st.session_state["sv_ratings"]
    comments = st.session_state["sv_comments"]

    for k, label in CATEGORIES:
        with st.container(border=True):
            st.markdown(f"**{label}**")
            ratings[k] = st.radio(
                f"rate_{k}", [1, 2, 3, 4, 5],
                format_func=lambda n: f"{n} · {RATING_LABELS[n]}",
                horizontal=True, index=(ratings[k] - 1) if ratings.get(k) else None,
                key=f"rate_{k}", label_visibility="collapsed")
            need = ratings.get(k) in (1, 2)
            comments[k] = st.text_input(
                ("Please explain (required)" if need else "Comment (optional)"),
                comments.get(k, ""), key=f"cmt_{k}")

    st.markdown("##### A little more")
    main_complaint = st.text_area("Main complaint", st.session_state.get("sv_main", ""), key="sv_main")
    improvement = st.text_area("Suggested improvement", st.session_state.get("sv_impr", ""), key="sv_impr")
    best = st.text_area("Best thing about housing", st.session_state.get("sv_best", ""), key="sv_best")

    all_rated = all(ratings.get(k) in (1, 2, 3, 4, 5) for k in CAT_KEYS)
    low_missing = [CATEGORIES_d[k] for k in CAT_KEYS if ratings.get(k) in (1, 2) and not comments.get(k, "").strip()]
    valid = all_rated and not low_missing

    c1, c2 = st.columns([1, 1])
    if c1.button("← Back"):
        st.session_state["sv_step"] = "verify"; st.rerun()
    if c2.button("Continue to VIP →", type="primary", disabled=not valid):
        st.session_state["sv_step"] = "vip"; st.rerun()
    if low_missing:
        st.caption("⚠️ Please explain your low ratings (1–2) for: " + ", ".join(low_missing))
    elif not all_rated:
        st.caption("⚠️ Every category must be rated before continuing.")


CATEGORIES_d = dict(CATEGORIES)


def _step_vip():
    st.subheader("VIP Housing")
    st.info("**VIP Housing** offers better privacy, higher room quality, premium furniture, "
            "air conditioning, premium facilities and an improved living experience.")
    interested = st.radio("Are you interested in VIP Housing?", ["Yes", "No"], horizontal=True,
                          index=None, key="sv_vip_int")

    reason = features = extra = price = suggestions = phone = None
    barriers = []
    if interested == "Yes":
        reason = st.selectbox("Main reason you would consider moving to VIP Housing",
                              VIP_REASONS, index=None, key="sv_vip_reason")
        features = st.multiselect("What features do you expect in VIP Housing?", VIP_FEATURES, key="sv_vip_feat")
        extra = st.text_area("What additional services would encourage you to join?", key="sv_vip_extra")
        price = st.radio("Would you accept a monthly fee between 15,000 and 20,000 PKR?",
                         ["Yes", "Maybe", "No"], horizontal=True, index=None, key="sv_vip_price")
        suggestions = st.text_area("Additional suggestions for VIP Housing", key="sv_vip_sugg")
        st.markdown("##### Contact (so the housing office can follow up)")
        phone = st.text_input("Phone number", key="sv_vip_phone")
    elif interested == "No":
        barriers = st.multiselect("What might prevent you from moving to VIP Housing?",
                                  VIP_BARRIERS, key="sv_vip_barrier")

    can_submit = interested is not None and (interested == "No" or (reason and price))

    c1, c2 = st.columns([1, 1])
    if c1.button("← Back"):
        st.session_state["sv_step"] = "survey" if st.session_state["sv_is_resident"] else "verify"; st.rerun()
    if c2.button("Submit feedback", type="primary", disabled=not can_submit):
        _save(interested == "Yes", reason, features or [], extra, price, barriers, suggestions, phone)


def _save(vip_yes, reason, features, extra, price, barriers, suggestions, phone):
    info = st.session_state["sv_info"]
    is_res = st.session_state["sv_is_resident"]
    db = SessionLocal()
    sub = Submission(
        name=info["name"], student_id=info["student_id"], email=info["email"],
        academic_level=info["academic_level"], room=info["room"],
        block=info["block"] if is_res else None, is_resident=is_res,
        ratings=st.session_state["sv_ratings"] if is_res else {},
        comments=st.session_state["sv_comments"] if is_res else {},
        main_complaint=st.session_state.get("sv_main", ""),
        suggested_improvement=st.session_state.get("sv_impr", ""),
        best_thing=st.session_state.get("sv_best", ""),
        vip_interested=vip_yes, vip_reason=reason, vip_features=features,
        vip_extra_services=extra, vip_price_ok=price, vip_barrier=barriers,
        vip_suggestions=suggestions, lead_phone=phone)
    db.add(sub)
    try:
        db.commit()
        st.session_state["sv_step"] = "done"
        db.close(); st.rerun()
    except IntegrityError:
        db.rollback(); db.close()
        st.error("A response has already been submitted for this Student ID, email and room. "
                 "Each student may submit only once.")


def _step_done():
    st.markdown("<div style='text-align:center;padding:40px 0'>"
                "<div style='font-size:48px'>✓</div>"
                "<h2>Thank you for your participation</h2>"
                "<p style='color:#6A7686'>Your feedback helps improve student living at IIUI.</p></div>",
                unsafe_allow_html=True)
    if st.button("Submit another response"):
        reset(); st.rerun()
