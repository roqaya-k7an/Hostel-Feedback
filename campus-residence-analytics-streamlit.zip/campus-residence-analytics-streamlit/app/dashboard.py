"""Admin-only analytics dashboard. Every figure is computed live from the
submissions table via app.analytics. Includes filters and CSV/Excel/PDF export."""
import io
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from . import analytics as A
from .analytics import health_band
from .db import BLOCKS, ACADEMIC_LEVELS, CAT_KEYS, CAT_LABEL
from .theme import kpi, alert, insight_bars, PLOTLY_SEQ, GREEN, GOLD, NAVY, RED


def _plotly(fig, h=300):
    fig.update_layout(margin=dict(l=8, r=8, t=10, b=8), height=h,
                      font=dict(family="-apple-system,Segoe UI,sans-serif", size=12),
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      legend=dict(orientation="h", y=-0.18))
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})


def run_dashboard():
    df, roster = A.load_dataframe()

    # ---------------- filters ----------------
    with st.sidebar:
        st.markdown("### Filters")
        f_blocks = st.multiselect("Block", BLOCKS, default=BLOCKS)
        f_levels = st.multiselect("Academic level", ACADEMIC_LEVELS, default=ACADEMIC_LEVELS)
        f_sat = st.slider("Overall satisfaction", 1, 5, (1, 5))
        f_vip = st.selectbox("VIP interest", ["All", "Interested", "Not interested"])

    if len(df):
        m = df["academic_level"].isin(f_levels)
        m &= df["block"].isin(f_blocks) | df["block"].isna()
        sat = df["rating_overall"].fillna(0)
        m &= (~df["is_resident"]) | ((sat >= f_sat[0]) & (sat <= f_sat[1]))
        if f_vip == "Interested":
            m &= df["vip_interested"] == True       # noqa: E712
        elif f_vip == "Not interested":
            m &= df["vip_interested"] == False       # noqa: E712
        df = df[m]

    st.title("Campus Residence Analytics")
    st.caption("Decision-support dashboard · live data from verified student feedback")

    if not len(df):
        st.info("No responses match the current filters yet. As verified residents submit the "
                "survey, every section below fills in automatically — there is no placeholder data.")
        return

    ov = A.overview(df, roster)

    # ---------------- PRIORITY ACTION CENTER ----------------
    st.markdown("#### 🚨 Priority Action Center")
    pc = A.priority_center(df)
    a, b, c, d = st.columns(4)
    wb = pc["worst_block"]
    alert(a, "red", "Most problematic block",
          f"Block {wb['block']}" if wb else "—",
          f"Health {wb['health']}/100" if wb else "Awaiting data")
    ws = pc["worst_service"]
    alert(b, "amber", "Lowest-rated service",
          ws["label"] if ws else "—", f"{ws['avg']}/5 average" if ws else "Awaiting data")
    tc = pc["top_complaint"]
    alert(c, "navy", "Most common complaint",
          tc["label"] if tc else "—", f"{tc['count']} mentions" if tc else "Awaiting data")
    n_crit = len(pc["critical_blocks"])
    alert(d, "green" if n_crit == 0 else "red", "Immediate attention",
          f"{n_crit} block(s)", "Below 50/100 health" if n_crit else "All blocks healthy")

    st.divider()

    # ---------------- KPI CARDS ----------------
    cols = st.columns(5)
    kpi(cols[0], ov["total_responses"], "Total responses")
    kpi(cols[1], f"{ov['participation_rate']}%", "Participation rate", f"{ov['total_residents']} of {ov['roster']}")
    kpi(cols[2], ov["overall_satisfaction"], "Overall satisfaction", "out of 5")
    kpi(cols[3], ov["total_residents"], "Total residents")
    kpi(cols[4], ov["vip_demand"], "VIP demand", "interested students")

    bt = [x for x in A.block_table(df) if x["residents"] > 0 and x["health"] is not None]
    best = max(bt, key=lambda x: x["health"], default=None)
    worst = min(bt, key=lambda x: x["health"], default=None)
    ins = A.comment_insights(df)
    cols = st.columns(4)
    kpi(cols[0], f"Block {best['block']}" if best else "—", "Best performing block",
        f"{best['health']}/100" if best else "")
    kpi(cols[1], f"Block {worst['block']}" if worst else "—", "Worst performing block",
        f"{worst['health']}/100" if worst else "")
    kpi(cols[2], ins["complaints"][0]["label"] if ins["complaints"] else "—", "Most common complaint")
    kpi(cols[3], ins["appreciated"][0]["label"] if ins["appreciated"] else "—", "Most appreciated service")

    st.divider()

    # ---------------- HOUSING HEALTH SCORE ----------------
    st.markdown("#### Housing Health Score by block")
    hc = st.columns(len(BLOCKS))
    for i, row in enumerate(A.block_table(df)):
        band, color = health_band(row["health"])
        val = f"{row['health']}/100" if row["health"] is not None else "—"
        hc[i].markdown(
            f"<div class='kpi' style='text-align:center'><div class='lab'>Block {row['block']}</div>"
            f"<div class='num' style='color:{color}'>{val}</div>"
            f"<span class='pill' style='background:{color}'>{band}</span>"
            f"<div class='sub'>{row['residents']} residents</div></div>", unsafe_allow_html=True)

    st.write("")
    left, right = st.columns([1.3, 1])
    with left:
        st.markdown("##### Overall satisfaction by block")
        bdf = pd.DataFrame(A.block_table(df))
        bdf = bdf[bdf["residents"] > 0]
        if len(bdf):
            fig = px.bar(bdf, x="block", y="satisfaction", color="satisfaction",
                         color_continuous_scale=["#B5462F", "#C8A04B", "#0E5A46"], range_y=[0, 5])
            fig.update_coloraxes(showscale=False)
            _plotly(fig, 280)
    with right:
        st.markdown("##### Satisfaction distribution")
        res = df[df["is_resident"] == True]  # noqa: E712
        dist = res["rating_overall"].dropna().value_counts().reindex([1, 2, 3, 4, 5], fill_value=0)
        fig = go.Figure(go.Pie(labels=[f"{i} ★" for i in dist.index], values=dist.values, hole=.6,
                               marker=dict(colors=["#B5462F", "#cf7a5f", "#C8A04B", "#15735A", "#0E5A46"])))
        _plotly(fig, 280)

    st.divider()

    # ---------------- TOP / LOWEST SERVICES ----------------
    st.markdown("#### Service performance")
    svc = A.service_scores(df)
    if svc:
        c1, c2 = st.columns(2)
        with c1:
            st.markdown("##### ✅ Top performing services")
            for s in svc[:5]:
                st.markdown(f"<div class='ibar pos'><div class='t'><b>{s['label']}</b>"
                            f"<span>{s['avg']}/5 · {s['pct']}%</span></div>"
                            f"<div class='track'><i style='width:{s['pct']}%'></i></div></div>",
                            unsafe_allow_html=True)
        with c2:
            st.markdown("##### ⚠️ Lowest performing services")
            for s in svc[::-1][:5]:
                st.markdown(f"<div class='ibar neg'><div class='t'><b>{s['label']}</b>"
                            f"<span>{s['avg']}/5 · {s['pct']}%</span></div>"
                            f"<div class='track'><i style='width:{s['pct']}%'></i></div></div>",
                            unsafe_allow_html=True)

    st.divider()

    # ---------------- ACADEMIC ----------------
    st.markdown("#### Academic level analytics")
    ac = A.academic_breakdown(df)
    cols = st.columns(3)
    for i, a_ in enumerate(ac):
        kpi(cols[i], a_["count"], f"{a_['level']} students", f"{a_['percent']}% · satisfaction {a_['satisfaction']}/5")
    c1, c2 = st.columns(2)
    with c1:
        fig = px.pie(pd.DataFrame(ac), names="level", values="count", hole=.4,
                     color_discrete_sequence=[GREEN, GOLD, NAVY])
        _plotly(fig, 260)
    with c2:
        fig = px.bar(pd.DataFrame(ac), x="level", y="satisfaction", range_y=[0, 5],
                     color_discrete_sequence=[GREEN])
        _plotly(fig, 260)

    st.divider()

    # ---------------- COMMENT INSIGHTS ----------------
    st.markdown("#### Comment insights")
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("##### Most common complaints"); insight_bars(ins["complaints"], "neg")
        st.markdown("##### Most mentioned problems"); insight_bars(ins["problems"], "neg")
    with c2:
        st.markdown("##### Most common suggestions"); insight_bars(ins["suggestions"], "pos")
        st.markdown("##### Most appreciated services"); insight_bars(ins["appreciated"], "pos")

    st.divider()

    # ---------------- BLOCK DRILLDOWN ----------------
    st.markdown("#### Block analytics")
    available = [r["block"] for r in A.block_table(df) if r["residents"] > 0]
    if available:
        sel = st.selectbox("Open a block for dedicated analytics", available)
        _block_detail(df, sel)

    st.divider()

    # ---------------- VIP ----------------
    st.markdown("#### VIP housing insights")
    vip = A.vip_analytics(df)
    cols = st.columns(4)
    kpi(cols[0], vip["interested"], "Interested students")
    kpi(cols[1], f"{vip['price_accept_rate']}%", "Price acceptance", "15,000–20,000 PKR")
    kpi(cols[2], vip["price_maybe"], "Maybe on price")
    kpi(cols[3], vip["price_no"], "Reject price")
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("##### Main reasons for interest"); insight_bars(vip["reasons"], "pos")
        st.markdown("##### Top requested features"); insight_bars(vip["features"], "pos")
    with c2:
        st.markdown("##### Main barriers"); insight_bars(vip["barriers"], "neg")
        st.markdown("##### Price response")
        fig = go.Figure(go.Pie(labels=["Yes", "Maybe", "No"],
                               values=[vip["price_yes"], vip["price_maybe"], vip["price_no"]], hole=.55,
                               marker=dict(colors=[GREEN, GOLD, RED])))
        _plotly(fig, 240)

    st.divider()
    _exports(df)


def _block_detail(df, block):
    bd = next((r for r in A.block_table(df) if r["block"] == block), None)
    scores = A.block_service_scores(df, block)
    comments = A.block_comments(df, block)
    cols = st.columns(4)
    band, color = health_band(bd["health"])
    kpi(cols[0], bd["residents"], "Residents")
    kpi(cols[1], f"{bd['satisfaction']}/5", "Avg satisfaction")
    cols[2].markdown(f"<div class='kpi' style='text-align:center'><div class='lab'>Health score</div>"
                     f"<div class='num' style='color:{color}'>{bd['health']}/100</div>"
                     f"<span class='pill' style='background:{color}'>{band}</span></div>", unsafe_allow_html=True)
    kpi(cols[3], f"{bd['complaints']} / {bd['suggestions']}", "Complaints / suggestions")

    st.write("")
    c1, c2 = st.columns([1.2, 1])
    with c1:
        st.markdown("##### Service ratings")
        sdf = pd.DataFrame([{"service": k, "score": v} for k, v in scores.items()])
        fig = px.bar(sdf, x="score", y="service", orientation="h", range_x=[0, 5],
                     color="score", color_continuous_scale=["#B5462F", "#C8A04B", "#0E5A46"])
        fig.update_coloraxes(showscale=False)
        _plotly(fig, 360)
    with c2:
        st.markdown("##### Most common issues")
        insight_bars(A.comment_insights(df[df["block"] == block])["problems"], "neg")

    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown("**Positive comments**")
        for x in comments["positive"][:8]:
            st.markdown(f"<div class='comment pos'><div class='area'>{x['area']} · {x['rating']}★</div>{x['text']}</div>", unsafe_allow_html=True)
        if not comments["positive"]:
            st.caption("None yet.")
    with c2:
        st.markdown("**Negative comments**")
        for x in comments["negative"][:8]:
            st.markdown(f"<div class='comment neg'><div class='area'>{x['area']} · {x['rating']}★</div>{x['text']}</div>", unsafe_allow_html=True)
        if not comments["negative"]:
            st.caption("None yet.")
    with c3:
        st.markdown("**Suggestions**")
        for x in comments["suggestions"][:8]:
            st.markdown(f"<div class='comment'>{x['text']}</div>", unsafe_allow_html=True)
        if not comments["suggestions"]:
            st.caption("None yet.")


def _exports(df):
    st.markdown("#### Export")
    flat = df.drop(columns=["_ratings", "_comments"], errors="ignore")
    c1, c2, c3 = st.columns(3)
    c1.download_button("⬇ CSV", flat.to_csv(index=False).encode(), "responses.csv", "text/csv")

    xbuf = io.BytesIO()
    with pd.ExcelWriter(xbuf, engine="openpyxl") as w:
        flat.to_excel(w, index=False, sheet_name="Responses")
    c2.download_button("⬇ Excel", xbuf.getvalue(), "responses.xlsx",
                       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

    c3.download_button("⬇ PDF summary", _pdf_summary(df), "summary.pdf", "application/pdf")


def _pdf_summary(df):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import cm
    from reportlab.pdfgen import canvas
    _, roster = A.load_dataframe()
    ov = A.overview(df, roster)
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    W, H = A4
    y = H - 2 * cm
    c.setFillColorRGB(0.055, 0.353, 0.275)
    c.rect(0, H - 1.4 * cm, W, 1.4 * cm, fill=1, stroke=0)
    c.setFillColorRGB(1, 1, 1); c.setFont("Helvetica-Bold", 14)
    c.drawString(2 * cm, H - 0.95 * cm, "Campus Residence Analytics — Executive Summary")
    c.setFillColorRGB(0.1, 0.13, 0.18); c.setFont("Helvetica", 11); y = H - 2.6 * cm
    lines = [
        f"Total responses: {ov['total_responses']}",
        f"Total residents: {ov['total_residents']}   Participation: {ov['participation_rate']}%",
        f"Overall satisfaction: {ov['overall_satisfaction']} / 5",
        f"VIP interested students: {ov['vip_demand']}",
    ]
    bt = [x for x in A.block_table(df) if x["residents"] > 0 and x["health"] is not None]
    if bt:
        best = max(bt, key=lambda x: x["health"]); worst = min(bt, key=lambda x: x["health"])
        lines += [f"Best block: {best['block']} ({best['health']}/100)",
                  f"Worst block: {worst['block']} ({worst['health']}/100)"]
    for ln in lines:
        c.drawString(2 * cm, y, ln); y -= 0.7 * cm
    c.showPage(); c.save()
    return buf.getvalue()
