"""Campus Residence Analytics — Streamlit entrypoint.

Run:  streamlit run app/main.py
Students see only the survey. Administrators (password) see only the dashboard.
"""
import os
import csv
import io
import streamlit as st

from .db import init_db, SessionLocal, Resident
from .theme import inject_css
from .survey import run_survey, reset
from .dashboard import run_dashboard

ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "iiui-admin")

st.set_page_config(page_title="Campus Residence Analytics", page_icon="🏠", layout="wide")
init_db()
inject_css()

if "role" not in st.session_state:
    st.session_state["role"] = None


def _header():
    c1, c2 = st.columns([1, 1])
    with c1:
        st.markdown("<div style='display:flex;align-items:center;gap:12px'>"
                    "<div style='width:38px;height:38px;border-radius:50%;background:"
                    "radial-gradient(circle at 50% 38%,#E7D6A8,#C8A04B 60%,#9c7a2f);display:flex;"
                    "align-items:center;justify-content:center;color:#3a2d08;font-weight:700;font-family:Georgia'>IIUI</div>"
                    "<div><b style='font-family:Georgia'>Campus Residence Analytics</b><br>"
                    "<span style='font-size:12px;color:#6A7686'>International Islamic University Islamabad</span></div></div>",
                    unsafe_allow_html=True)
    with c2:
        if st.session_state["role"]:
            if st.button("← Switch role", key="switch"):
                reset()
                st.session_state["role"] = None
                st.session_state.pop("admin_ok", None)
                st.rerun()


def _landing():
    st.write(""); st.write("")
    c = st.columns([1, 2, 1])[1]
    with c:
        st.markdown("<h1 style='text-align:center'>Welcome</h1>", unsafe_allow_html=True)
        st.markdown("<p style='text-align:center;color:#6A7686'>Transforming student feedback "
                    "into better housing decisions.</p>", unsafe_allow_html=True)
        st.write("")
        if st.button("🎓  I'm a student — give feedback", use_container_width=True, type="primary"):
            st.session_state["role"] = "student"; st.rerun()
        st.write("")
        if st.button("🛠️  I'm an administrator", use_container_width=True):
            st.session_state["role"] = "admin_login"; st.rerun()


def _admin_login():
    c = st.columns([1, 2, 1])[1]
    with c:
        st.subheader("Administrator access")
        pw = st.text_input("Password", type="password")
        if st.button("Sign in", type="primary"):
            if pw == ADMIN_PASSWORD:
                st.session_state["role"] = "admin"; st.session_state["admin_ok"] = True; st.rerun()
            else:
                st.error("Incorrect password.")
        with st.expander("Import / update housing roster (admin)"):
            up = st.file_uploader("Roster CSV (student_id,name,email,room,block,academic_level)", type="csv")
            if up and st.button("Import roster"):
                _import(up)


def _import(file):
    text = io.StringIO(file.getvalue().decode("utf-8-sig"))
    reader = csv.DictReader(text)
    db = SessionLocal(); added = 0
    for row in reader:
        if db.query(Resident).filter_by(student_id=row["student_id"].strip(),
                                        email=row["email"].strip(),
                                        room=row["room"].strip()).first():
            continue
        db.add(Resident(student_id=row["student_id"].strip(), name=row["name"].strip(),
                        email=row["email"].strip(), room=row["room"].strip(),
                        block=row["block"].strip().upper(),
                        academic_level=row["academic_level"].strip())); added += 1
    db.commit(); n = db.query(Resident).count(); db.close()
    st.success(f"Imported {added}. Roster size: {n}")


# ---------------- routing ----------------
_header()
st.write("")
role = st.session_state["role"]
if role is None:
    _landing()
elif role == "student":
    run_survey()
elif role == "admin_login":
    _admin_login()
elif role == "admin" and st.session_state.get("admin_ok"):
    run_dashboard()
else:
    st.session_state["role"] = None
    st.rerun()
