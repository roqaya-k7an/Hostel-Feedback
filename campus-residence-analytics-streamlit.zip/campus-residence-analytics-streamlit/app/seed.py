"""Import the housing roster (reference data only). Usage: python -m app.seed"""
import csv, os
from .db import init_db, SessionLocal, Resident

def run(path=None):
    path = path or os.path.join(os.path.dirname(__file__), "residents.csv")
    init_db()
    db = SessionLocal(); added = 0
    with open(path, encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            if db.query(Resident).filter_by(student_id=row["student_id"].strip(),
                                            email=row["email"].strip(),
                                            room=row["room"].strip()).first():
                continue
            db.add(Resident(student_id=row["student_id"].strip(), name=row["name"].strip(),
                            email=row["email"].strip(), room=row["room"].strip(),
                            block=row["block"].strip().upper(),
                            academic_level=row["academic_level"].strip())); added += 1
    db.commit()
    print(f"Imported {added}. Roster size: {db.query(Resident).count()}"); db.close()

if __name__ == "__main__":
    run()
