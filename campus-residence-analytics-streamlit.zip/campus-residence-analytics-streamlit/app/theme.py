"""Shared visual theme: CSS + small HTML component helpers (KPI cards, alerts,
health pills, insight bars). Keeps app.py and dashboard.py readable."""
import streamlit as st

GREEN = "#0E5A46"; GREEN6 = "#15735A"; GOLD = "#C8A04B"; NAVY = "#16233D"
RED = "#B5462F"; AMBER = "#C8862B"; MUTED = "#6A7686"
PLOTLY_SEQ = ["#0E5A46", "#15735A", "#3f8f74", "#C8A04B", "#d9bd7e", "#16233D", "#27395C", "#9aa7b8"]


def inject_css():
    st.markdown("""
    <style>
      .stApp { background:#F4F6F5; }
      .block-container { padding-top:1.4rem; max-width:1180px; }
      h1,h2,h3 { font-family:"Iowan Old Style","Palatino Linotype",Georgia,serif; color:#16202B; }
      /* KPI cards */
      .kpi { background:#fff; border:1px solid #E4E9E6; border-radius:14px; padding:16px 18px;
             box-shadow:0 1px 2px rgba(16,40,30,.06); position:relative; overflow:hidden; height:100%; }
      .kpi::before { content:""; position:absolute; top:0; left:0; right:0; height:3px;
             background:linear-gradient(90deg,#0E5A46,#C8A04B); }
      .kpi .num { font-family:"Iowan Old Style",Georgia,serif; font-size:26px; margin:6px 0 2px; color:#16202B; }
      .kpi .lab { font-size:12.5px; color:#6A7686; font-weight:600; }
      .kpi .sub { font-size:11.5px; color:#8a93a3; margin-top:4px; }
      /* alert cards */
      .alert { border-radius:14px; padding:16px 18px; color:#fff; height:100%; }
      .alert .l { font-size:10.5px; letter-spacing:1px; text-transform:uppercase; opacity:.9; font-weight:700; }
      .alert .b { font-family:"Iowan Old Style",Georgia,serif; font-size:22px; margin:6px 0 2px; }
      .alert .s { font-size:12.5px; opacity:.92; }
      .a-red { background:linear-gradient(135deg,#9a4231,#B5462F); }
      .a-amber { background:linear-gradient(135deg,#b9802f,#C8862B); }
      .a-navy { background:linear-gradient(135deg,#16233D,#27395C); }
      .a-green { background:linear-gradient(135deg,#15735A,#0E5A46); }
      /* health pill */
      .pill { display:inline-block; padding:4px 12px; border-radius:99px; color:#fff; font-weight:700; font-size:13px; }
      /* insight bar */
      .ibar { margin-bottom:11px; }
      .ibar .t { display:flex; justify-content:space-between; font-size:13.5px; margin-bottom:4px; }
      .ibar .t span { color:#6A7686; font-weight:600; }
      .ibar .track { height:9px; background:#EEF2F0; border-radius:99px; overflow:hidden; }
      .ibar .track i { display:block; height:100%; }
      .ibar.pos .track i { background:linear-gradient(90deg,#15735A,#0E5A46); }
      .ibar.neg .track i { background:linear-gradient(90deg,#cf7a5f,#B5462F); }
      .sectitle { font-size:11px; letter-spacing:2px; text-transform:uppercase; color:#15735A;
             font-weight:700; margin:6px 0 2px; font-family:-apple-system,Segoe UI,sans-serif; }
      .comment { border-left:3px solid #E4E9E6; padding:8px 12px; margin-bottom:8px; background:#fafcfb;
             border-radius:0 8px 8px 0; font-size:13px; }
      .comment.pos { border-color:#0E5A46; } .comment.neg { border-color:#B5462F; }
      .comment .area { font-size:10.5px; font-weight:700; color:#6A7686; text-transform:uppercase; }
      .stButton>button, .stDownloadButton>button { border-radius:10px; font-weight:600; }
      div[data-testid="stMetricValue"] { font-family:"Iowan Old Style",Georgia,serif; }
    </style>
    """, unsafe_allow_html=True)


def kpi(col, num, lab, sub=""):
    col.markdown(f"<div class='kpi'><div class='num'>{num}</div><div class='lab'>{lab}</div>"
                 f"<div class='sub'>{sub}</div></div>", unsafe_allow_html=True)


def alert(col, kind, label, big, small):
    col.markdown(f"<div class='alert a-{kind}'><div class='l'>{label}</div>"
                 f"<div class='b'>{big}</div><div class='s'>{small}</div></div>",
                 unsafe_allow_html=True)


def insight_bars(items, cls):
    if not items:
        st.caption("No data yet.")
        return
    mx = max(i["count"] for i in items)
    html = ""
    for i in items:
        w = round(i["count"] / mx * 100)
        html += (f"<div class='ibar {cls}'><div class='t'><b>{i['label']}</b>"
                 f"<span>{i['count']}</span></div><div class='track'><i style='width:{w}%'></i></div></div>")
    st.markdown(html, unsafe_allow_html=True)
